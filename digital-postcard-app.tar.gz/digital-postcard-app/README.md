# Digital Postcard App

A location-based digital postcard app for travelers to create and share personalized postcards.

## Features

- **Location Detection**: Automatically detects the user's current location or allows manual selection
- **Curated Images**: Beautiful, professional photographs of destinations worldwide
- **Personalization**: Add custom messages or handwritten notes to postcards
- **Multi-channel Sharing**: Share digital postcards via WhatsApp, email, social media, etc.
- **Physical Delivery**: Option to have postcards printed and delivered anywhere in the world
- **Sustainable Options**: Choose local printing near the recipient for faster delivery and reduced carbon footprint
- **Progressive Web App**: Works on all devices with offline capabilities

## Technology Stack

- **Frontend**: React, React Router
- **Build Tool**: Vite
- **PWA Support**: Workbox
- **Styling**: CSS with CSS Variables for theming
- **Image Sources**: Integration with Unsplash/Pexels APIs (planned)
- **Print Fulfillment**: Integration with Gelato/Printful APIs (planned)

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/digital-postcard-app.git
   cd digital-postcard-app
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the development server:
   ```
   npm run dev
   ```

4. Open your browser and navigate to `http://localhost:3000`

## Project Structure

```
digital-postcard-app/
├── public/                  # Static assets
│   ├── favicon.svg          # App icon
│   ├── manifest.json        # PWA manifest
│   └── sw.js                # Service Worker
├── src/                     # Source code
│   ├── components/          # UI components
│   │   ├── common/          # Shared components
│   │   └── layout/          # Layout components
│   ├── hooks/               # Custom React hooks
│   ├── pages/               # Page components
│   ├── services/            # API services
│   ├── context/             # React context
│   ├── assets/              # Images, fonts, etc.
│   ├── App.jsx              # Main app component
│   ├── main.jsx             # Entry point
│   └── index.css            # Global styles
├── package.json             # Dependencies and scripts
└── vite.config.js           # Vite configuration
```

## Deployment

To build the app for production:

```
npm run build
```

The build artifacts will be stored in the `dist/` directory.

## License

This project is licensed under the ISC License.

## Acknowledgements

- Images provided by [Unsplash](https://unsplash.com) and [Pexels](https://pexels.com)
- Print fulfillment powered by [Gelato](https://gelato.com)