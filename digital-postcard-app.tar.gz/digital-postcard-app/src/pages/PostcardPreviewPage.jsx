import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './PostcardPreviewPage.css';

// In a real app, this would fetch the postcard data from an API
// For now, we'll just use mock data
const getPostcardData = (postcardId) => {
  // Extract location ID from the postcard ID
  const locationId = postcardId.split('-')[0];
  
  // Mock data based on location
  return {
    id: postcardId,
    location: {
      name: locationId.charAt(0).toUpperCase() + locationId.slice(1),
      country: locationId === 'paris' ? 'France' : 
               locationId === 'rome' ? 'Italy' : 
               locationId === 'newyork' ? 'USA' : 'Worldwide'
    },
    image: {
      url: `https://source.unsplash.com/random/800x600/?${locationId}`,
      title: `${locationId.charAt(0).toUpperCase() + locationId.slice(1)} View`,
      photographer: 'Unsplash Photographer'
    },
    message: 'Having a wonderful time in this beautiful place! The views are breathtaking and the food is amazing. Wish you were here to enjoy it with me!',
    recipient: 'Friend',
    sender: 'Your Name',
    created: new Date().toISOString()
  };
};

const PostcardPreviewPage = () => {
  const { postcardId } = useParams();
  const navigate = useNavigate();
  const [postcard, setPostcard] = useState(null);
  const [deliveryMethod, setDeliveryMethod] = useState('digital');
  const [showPrintModal, setShowPrintModal] = useState(false);
  const [deliveryAddress, setDeliveryAddress] = useState({
    name: '',
    street: '',
    city: '',
    state: '',
    postal: '',
    country: ''
  });
  const [printOption, setPrintOption] = useState('local');

  useEffect(() => {
    // In a real app, this would be an API call
    const data = getPostcardData(postcardId);
    setPostcard(data);
  }, [postcardId]);

  const handleDeliveryMethodChange = (method) => {
    setDeliveryMethod(method);
  };

  const handlePrintOptionChange = (option) => {
    setPrintOption(option);
  };

  const handleDeliveryAddressChange = (e) => {
    const { name, value } = e.target;
    setDeliveryAddress(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePrintDetails = () => {
    setShowPrintModal(true);
  };

  const handleCloseModal = () => {
    setShowPrintModal(false);
  };

  const handleContinue = () => {
    // In a real app, this would save the delivery preferences
    navigate(`/share/${postcardId}`);
  };

  const handleEdit = () => {
    // In a real app, this would navigate back to the design page with the data
    navigate(-1);
  };

  if (!postcard) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading postcard preview...</p>
      </div>
    );
  }

  return (
    <div className="postcard-preview-page">
      <div className="container">
        <h1 className="page-title">Preview Your Postcard</h1>
        
        <div className="preview-container">
          <div className="postcard-full-preview">
            <div className="postcard-front-preview">
              <img 
                src={postcard.image.url} 
                alt={postcard.image.title}
                className="postcard-full-image"
                onError={(e) => {
                  e.target.onerror = null;
                  e.target.src = `https://via.placeholder.com/800x600?text=${postcard.location.name}`;
                }}
              />
              <div className="postcard-caption">
                <span className="location-name">
                  {postcard.location.name}, {postcard.location.country}
                </span>
                <span className="photo-credit">
                  Photo by: {postcard.image.photographer}
                </span>
              </div>
            </div>
            
            <div className="postcard-back-preview">
              <div className="postcard-message-preview">
                {postcard.message}
              </div>
              
              <div className="postcard-recipient-preview">
                <span className="recipient-label">To:</span>
                <span className="recipient-name">{postcard.recipient}</span>
              </div>
              
              <div className="postcard-sender-preview">
                <span className="sender-name">From: {postcard.sender}</span>
              </div>
              
              <div className="postcard-stamp">
                <div className="stamp-content">
                  <span className="digital-stamp">Digital Postcard</span>
                  <span className="stamp-date">
                    {new Date(postcard.created).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="delivery-options">
            <h2 className="section-title">Delivery Method</h2>
            <div className="delivery-toggles">
              <button 
                className={`delivery-option ${deliveryMethod === 'digital' ? 'active' : ''}`}
                onClick={() => handleDeliveryMethodChange('digital')}
              >
                <span className="delivery-icon">📱</span>
                <span className="delivery-name">Digital</span>
                <span className="delivery-desc">Share instantly via apps or email</span>
              </button>
              
              <button 
                className={`delivery-option ${deliveryMethod === 'print' ? 'active' : ''}`}
                onClick={() => handleDeliveryMethodChange('print')}
              >
                <span className="delivery-icon">📬</span>
                <span className="delivery-name">Physical</span>
                <span className="delivery-desc">Printed and mailed worldwide</span>
              </button>
            </div>
            
            {deliveryMethod === 'print' && (
              <div className="print-options">
                <p className="print-details">
                  Your postcard can be printed and delivered as a real postcard to any address worldwide.
                </p>
                <button 
                  className="btn btn-secondary"
                  onClick={handlePrintDetails}
                >
                  Enter Delivery Details
                </button>
              </div>
            )}
          </div>
        </div>
        
        <div className="preview-actions">
          <button 
            className="btn btn-secondary"
            onClick={handleEdit}
          >
            Edit Postcard
          </button>
          
          <button 
            className="btn btn-primary"
            onClick={handleContinue}
          >
            Continue to Sharing
          </button>
        </div>
      </div>
      
      {/* Physical Delivery Modal */}
      {showPrintModal && (
        <div className="modal-overlay">
          <div className="modal-content print-modal">
            <button className="modal-close" onClick={handleCloseModal}>×</button>
            <h2>Physical Delivery Details</h2>
            
            <div className="delivery-methods">
              <h3>Printing Method</h3>
              <div className="print-method-toggles">
                <button 
                  className={`print-method ${printOption === 'local' ? 'active' : ''}`}
                  onClick={() => handlePrintOptionChange('local')}
                >
                  <div className="method-icon">🌱</div>
                  <div className="method-content">
                    <h4>Local Printing</h4>
                    <p>Printed near recipient for faster delivery and reduced carbon footprint</p>
                    <div className="method-details">
                      <span>✅ 3-5 days delivery</span>
                      <span>✅ Lower emissions</span>
                      <span>✅ $2.99</span>
                    </div>
                  </div>
                </button>
                
                <button 
                  className={`print-method ${printOption === 'international' ? 'active' : ''}`}
                  onClick={() => handlePrintOptionChange('international')}
                >
                  <div className="method-icon">🌍</div>
                  <div className="method-content">
                    <h4>Origin Country Mail</h4>
                    <p>Mailed from your current country with authentic local stamp</p>
                    <div className="method-details">
                      <span>✅ 7-14 days delivery</span>
                      <span>✅ Authentic stamp</span>
                      <span>✅ $3.99</span>
                    </div>
                  </div>
                </button>
              </div>
            </div>
            
            <div className="delivery-address">
              <h3>Recipient Address</h3>
              <form className="address-form">
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="name">Full Name</label>
                    <input 
                      type="text" 
                      id="name" 
                      name="name" 
                      value={deliveryAddress.name}
                      onChange={handleDeliveryAddressChange}
                      required
                    />
                  </div>
                </div>
                
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="street">Street Address</label>
                    <input 
                      type="text" 
                      id="street" 
                      name="street" 
                      value={deliveryAddress.street}
                      onChange={handleDeliveryAddressChange}
                      required
                    />
                  </div>
                </div>
                
                <div className="form-row two-columns">
                  <div className="form-group">
                    <label htmlFor="city">City</label>
                    <input 
                      type="text" 
                      id="city" 
                      name="city" 
                      value={deliveryAddress.city}
                      onChange={handleDeliveryAddressChange}
                      required
                    />
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="state">State/Province</label>
                    <input 
                      type="text" 
                      id="state" 
                      name="state" 
                      value={deliveryAddress.state}
                      onChange={handleDeliveryAddressChange}
                    />
                  </div>
                </div>
                
                <div className="form-row two-columns">
                  <div className="form-group">
                    <label htmlFor="postal">Postal Code</label>
                    <input 
                      type="text" 
                      id="postal" 
                      name="postal" 
                      value={deliveryAddress.postal}
                      onChange={handleDeliveryAddressChange}
                      required
                    />
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="country">Country</label>
                    <input 
                      type="text" 
                      id="country" 
                      name="country" 
                      value={deliveryAddress.country}
                      onChange={handleDeliveryAddressChange}
                      required
                    />
                  </div>
                </div>
              </form>
            </div>
            
            <div className="print-summary">
              <div className="print-cost">
                <span>Total Cost:</span>
                <span className="price">${printOption === 'local' ? '2.99' : '3.99'}</span>
              </div>
              
              <button 
                className="btn btn-primary"
                onClick={handleCloseModal}
              >
                Confirm Delivery Details
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PostcardPreviewPage;