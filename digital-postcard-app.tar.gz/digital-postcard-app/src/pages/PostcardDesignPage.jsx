import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './PostcardDesignPage.css';

// This would come from an API in the real implementation
const getLocationData = (locationId) => {
  const locations = {
    'paris': {
      name: 'Paris',
      country: 'France',
      images: [
        {
          id: 'paris-1',
          url: 'https://source.unsplash.com/random/800x600/?paris,eiffel',
          title: 'Eiffel Tower',
          photographer: 'Photographer 1',
          isPremium: false
        },
        {
          id: 'paris-2',
          url: 'https://source.unsplash.com/random/800x600/?paris,louvre',
          title: 'Louvre Museum',
          photographer: 'Photographer 2',
          isPremium: false
        },
        {
          id: 'paris-3',
          url: 'https://source.unsplash.com/random/800x600/?paris,montmartre',
          title: 'Montmartre',
          photographer: 'Photographer 3',
          isPremium: true
        },
        {
          id: 'paris-4',
          url: 'https://source.unsplash.com/random/800x600/?paris,notredame',
          title: 'Notre Dame Cathedral',
          photographer: 'Photographer 4',
          isPremium: true
        }
      ]
    },
    'rome': {
      name: 'Rome',
      country: 'Italy',
      images: [
        {
          id: 'rome-1',
          url: 'https://source.unsplash.com/random/800x600/?rome,colosseum',
          title: 'Colosseum',
          photographer: 'Photographer 5',
          isPremium: false
        },
        {
          id: 'rome-2',
          url: 'https://source.unsplash.com/random/800x600/?rome,vatican',
          title: 'Vatican City',
          photographer: 'Photographer 6',
          isPremium: false
        },
        {
          id: 'rome-3',
          url: 'https://source.unsplash.com/random/800x600/?rome,trevi',
          title: 'Trevi Fountain',
          photographer: 'Photographer 7',
          isPremium: true
        }
      ]
    },
    'current': {
      name: 'Current Location',
      country: 'Based on GPS',
      images: [
        {
          id: 'current-1',
          url: 'https://source.unsplash.com/random/800x600/?city',
          title: 'City View',
          photographer: 'Photographer 8',
          isPremium: false
        },
        {
          id: 'current-2',
          url: 'https://source.unsplash.com/random/800x600/?landmark',
          title: 'Local Landmark',
          photographer: 'Photographer 9',
          isPremium: false
        }
      ]
    },
    'custom': {
      name: 'Custom Location',
      country: 'Your Choice',
      images: [
        {
          id: 'custom-1',
          url: 'https://source.unsplash.com/random/800x600/?travel',
          title: 'Custom View 1',
          photographer: 'Photographer 10',
          isPremium: false
        },
        {
          id: 'custom-2',
          url: 'https://source.unsplash.com/random/800x600/?landscape',
          title: 'Custom View 2',
          photographer: 'Photographer 11',
          isPremium: false
        }
      ]
    }
  };

  // Add default data for any location not explicitly defined
  const defaultLocation = {
    name: locationId.charAt(0).toUpperCase() + locationId.slice(1),
    country: 'Worldwide',
    images: [
      {
        id: `${locationId}-1`,
        url: `https://source.unsplash.com/random/800x600/?${locationId}`,
        title: 'City View',
        photographer: 'Unsplash Photographer',
        isPremium: false
      },
      {
        id: `${locationId}-2`,
        url: `https://source.unsplash.com/random/800x600/?${locationId},landmark`,
        title: 'Famous Landmark',
        photographer: 'Unsplash Photographer',
        isPremium: false
      }
    ]
  };

  return locations[locationId] || defaultLocation;
};

const PostcardDesignPage = () => {
  const { locationId } = useParams();
  const navigate = useNavigate();
  const [location, setLocation] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [message, setMessage] = useState('');
  const [recipientName, setRecipientName] = useState('');
  const [step, setStep] = useState(1); // 1: Select image, 2: Add message
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [selectedPremiumId, setSelectedPremiumId] = useState(null);

  useEffect(() => {
    const locationData = getLocationData(locationId);
    setLocation(locationData);
    
    // Set the first non-premium image as default selected
    const defaultImage = locationData.images.find(img => !img.isPremium);
    if (defaultImage) {
      setSelectedImage(defaultImage);
    }
  }, [locationId]);

  const handleImageSelect = (image) => {
    if (image.isPremium) {
      setSelectedPremiumId(image.id);
      setShowPremiumModal(true);
    } else {
      setSelectedImage(image);
    }
  };

  const handlePremiumUnlock = () => {
    // In a real app, this would trigger payment processing
    // For now, just simulate unlocking the premium image
    const premiumImage = location.images.find(img => img.id === selectedPremiumId);
    setSelectedImage(premiumImage);
    setShowPremiumModal(false);
  };

  const handleCloseModal = () => {
    setShowPremiumModal(false);
    setSelectedPremiumId(null);
  };

  const handleMessageChange = (e) => {
    setMessage(e.target.value);
  };

  const handleRecipientChange = (e) => {
    setRecipientName(e.target.value);
  };

  const handleContinue = () => {
    if (step === 1) {
      setStep(2);
    } else {
      // Create a postcard ID (in a real app, this would be a database entry)
      const postcardId = `${locationId}-${Date.now()}`;
      navigate(`/preview/${postcardId}`);
    }
  };

  const handleBack = () => {
    if (step === 2) {
      setStep(1);
    } else {
      navigate('/select-location');
    }
  };

  if (!location) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading location data...</p>
      </div>
    );
  }

  return (
    <div className="postcard-design-page">
      <div className="container">
        <div className="design-header">
          <h1 className="page-title">
            {step === 1 ? 'Select a Postcard Design' : 'Add Your Message'}
          </h1>
          <p className="location-info">
            {location.name}, {location.country}
          </p>
        </div>

        {step === 1 && (
          <div className="image-selection">
            <div className="images-grid">
              {location.images.map((image) => (
                <div 
                  key={image.id}
                  className={`image-card ${selectedImage?.id === image.id ? 'selected' : ''}`}
                  onClick={() => handleImageSelect(image)}
                >
                  <div className="image-container">
                    <img 
                      src={image.url} 
                      alt={image.title}
                      className="postcard-preview-image"
                      onError={(e) => {
                        e.target.onerror = null;
                        e.target.src = `https://via.placeholder.com/800x600?text=${image.title}`;
                      }}
                    />
                    {image.isPremium && (
                      <div className="premium-badge">
                        <span>✨ Premium</span>
                      </div>
                    )}
                  </div>
                  <div className="image-info">
                    <h3 className="image-title">{image.title}</h3>
                    <p className="photographer">Photo by: {image.photographer}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="message-section">
            <div className="postcard-preview-container">
              <div className="postcard-preview-front">
                <img 
                  src={selectedImage.url} 
                  alt={selectedImage.title}
                  className="postcard-image-large"
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = `https://via.placeholder.com/800x600?text=${selectedImage.title}`;
                  }}
                />
                <div className="postcard-location-overlay">
                  <span>{location.name}, {location.country}</span>
                </div>
              </div>
              
              <div className="postcard-preview-back">
                <div className="postcard-message-area">
                  <textarea
                    className="message-input"
                    placeholder="Write your message here..."
                    value={message}
                    onChange={handleMessageChange}
                    maxLength="300"
                  ></textarea>
                  <div className="character-count">
                    {message.length}/300 characters
                  </div>
                </div>
                
                <div className="postcard-recipient">
                  <label htmlFor="recipient">To:</label>
                  <input
                    id="recipient"
                    type="text"
                    placeholder="Recipient's name"
                    value={recipientName}
                    onChange={handleRecipientChange}
                  />
                </div>
                
                <div className="postcard-sender">
                  <span>From: [Your Name]</span>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="design-actions">
          <button 
            className="btn btn-secondary"
            onClick={handleBack}
          >
            {step === 1 ? 'Back to Locations' : 'Back to Designs'}
          </button>
          
          <button 
            className="btn btn-primary"
            onClick={handleContinue}
            disabled={step === 1 && !selectedImage}
          >
            {step === 1 ? 'Continue to Message' : 'Preview Postcard'}
          </button>
        </div>
      </div>

      {/* Premium Content Modal */}
      {showPremiumModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <button className="modal-close" onClick={handleCloseModal}>×</button>
            <h2>Premium Content</h2>
            <p>This is a premium postcard design. Unlock it to use in your postcards.</p>
            
            <div className="premium-preview">
              <img 
                src={location.images.find(img => img.id === selectedPremiumId)?.url} 
                alt="Premium content preview"
                className="premium-image-preview"
                onError={(e) => {
                  e.target.onerror = null;
                  e.target.src = `https://via.placeholder.com/400x300?text=Premium+Content`;
                }}
              />
            </div>
            
            <div className="premium-options">
              <button 
                className="btn btn-primary"
                onClick={handlePremiumUnlock}
              >
                Unlock for $0.99
              </button>
              <div className="premium-note">
                <p>Or unlock all premium content with a subscription</p>
                <button className="btn btn-secondary">
                  See Subscription Plans
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PostcardDesignPage;