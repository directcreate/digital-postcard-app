import React from 'react';
import { Link } from 'react-router-dom';
import './HomePage.css';

const HomePage = () => {
  return (
    <div className="home-page">
      <section className="hero">
        <div className="container">
          <div className="hero-content">
            <h1 className="hero-title">Share Your Travel Moments</h1>
            <p className="hero-subtitle">
              Create beautiful digital postcards with professional images from your current location
              and share them instantly with friends and family.
            </p>
            <div className="hero-actions">
              <Link to="/select-location" className="btn btn-primary btn-lg">
                Create a Postcard
              </Link>
              <a href="#how-it-works" className="btn btn-secondary btn-lg">
                Learn More
              </a>
            </div>
          </div>
          <div className="hero-image">
            <div className="postcard-preview">
              <div className="postcard-front">
                <img 
                  src="/sample-postcard.jpg" 
                  alt="Sample postcard showing Eiffel Tower" 
                  className="postcard-image"
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = 'https://via.placeholder.com/500x350?text=Beautiful+Destination';
                  }}
                />
              </div>
              <div className="postcard-note">
                <span className="postcard-greeting">Greetings from Paris!</span>
                <p className="postcard-message">
                  Having an amazing time in the city of lights.
                  Wish you were here to enjoy the beautiful views with me!
                </p>
                <span className="postcard-signature">- Anna</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="how-it-works" className="how-it-works">
        <div className="container">
          <h2 className="section-title">How It Works</h2>
          <div className="steps-container">
            <div className="step">
              <div className="step-icon">📍</div>
              <h3 className="step-title">Choose Your Location</h3>
              <p className="step-description">
                We detect your current location or you can select any place in the world.
              </p>
            </div>
            <div className="step">
              <div className="step-icon">🖼️</div>
              <h3 className="step-title">Select a Postcard</h3>
              <p className="step-description">
                Browse professional, curated images of your chosen location.
              </p>
            </div>
            <div className="step">
              <div className="step-icon">✏️</div>
              <h3 className="step-title">Personalize It</h3>
              <p className="step-description">
                Add your message and customize your postcard.
              </p>
            </div>
            <div className="step">
              <div className="step-icon">📤</div>
              <h3 className="step-title">Share Instantly</h3>
              <p className="step-description">
                Send your postcard digitally via message, email, or social media.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="features">
        <div className="container">
          <h2 className="section-title">Features</h2>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">🌎</div>
              <h3 className="feature-title">Global Coverage</h3>
              <p className="feature-description">
                Access beautiful images from destinations worldwide, from famous landmarks to hidden gems.
              </p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">✨</div>
              <h3 className="feature-title">Professional Images</h3>
              <p className="feature-description">
                Curated, high-quality photos that capture the essence of each location.
              </p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">🖋️</div>
              <h3 className="feature-title">Personal Touch</h3>
              <p className="feature-description">
                Add typed messages or scan your handwritten notes for that authentic feel.
              </p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">📬</div>
              <h3 className="feature-title">Physical Delivery</h3>
              <p className="feature-description">
                Option to send your digital design as a real printed postcard, delivered globally.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="cta">
        <div className="container">
          <h2 className="cta-title">Ready to send your first postcard?</h2>
          <p className="cta-description">
            Start creating beautiful memories to share with your loved ones today.
          </p>
          <Link to="/select-location" className="btn btn-primary btn-lg">
            Create a Postcard Now
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;