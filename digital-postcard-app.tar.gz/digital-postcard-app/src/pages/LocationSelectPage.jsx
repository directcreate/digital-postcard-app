import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './LocationSelectPage.css';
import useGeolocation from '../hooks/useGeolocation';

// This would come from an API in the real implementation
const POPULAR_LOCATIONS = [
  { id: 'paris', name: 'Paris', country: 'France', image: 'https://source.unsplash.com/random/300x200/?paris' },
  { id: 'rome', name: 'Rome', country: 'Italy', image: 'https://source.unsplash.com/random/300x200/?rome' },
  { id: 'newyork', name: 'New York', country: 'USA', image: 'https://source.unsplash.com/random/300x200/?newyork' },
  { id: 'tokyo', name: 'Tokyo', country: 'Japan', image: 'https://source.unsplash.com/random/300x200/?tokyo' },
  { id: 'sydney', name: 'Sydney', country: 'Australia', image: 'https://source.unsplash.com/random/300x200/?sydney' },
  { id: 'london', name: 'London', country: 'UK', image: 'https://source.unsplash.com/random/300x200/?london' },
  { id: 'barcelona', name: 'Barcelona', country: 'Spain', image: 'https://source.unsplash.com/random/300x200/?barcelona' },
  { id: 'dubai', name: 'Dubai', country: 'UAE', image: 'https://source.unsplash.com/random/300x200/?dubai' },
];

const LocationSelectPage = () => {
  const { location, loading, error } = useGeolocation();
  const [currentLocation, setCurrentLocation] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredLocations, setFilteredLocations] = useState(POPULAR_LOCATIONS);
  const navigate = useNavigate();

  useEffect(() => {
    if (location) {
      // In a real app, we would make an API call to reverse geocode the coordinates
      // For now, we'll just simulate getting the location name
      setCurrentLocation({
        id: 'current',
        name: 'Your Current Location',
        country: 'Based on GPS',
        coordinates: `${location.latitude.toFixed(4)}, ${location.longitude.toFixed(4)}`,
        image: `https://source.unsplash.com/random/300x200/?city,${Date.now()}`
      });
    }
  }, [location]);

  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredLocations(POPULAR_LOCATIONS);
    } else {
      const query = searchQuery.toLowerCase();
      setFilteredLocations(
        POPULAR_LOCATIONS.filter(
          loc => loc.name.toLowerCase().includes(query) || 
                 loc.country.toLowerCase().includes(query)
        )
      );
    }
  }, [searchQuery]);

  const handleLocationSelect = (locationId) => {
    navigate(`/design/${locationId}`);
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  return (
    <div className="location-select-page">
      <div className="container">
        <h1 className="page-title">Select a Location</h1>
        
        <div className="search-container">
          <input
            type="text"
            className="search-input"
            placeholder="Search for a city or country..."
            value={searchQuery}
            onChange={handleSearchChange}
          />
          <button className="search-btn">
            🔍
          </button>
        </div>
        
        {loading && (
          <div className="location-status">
            <div className="location-loading">
              <div className="location-spinner"></div>
              <p>Detecting your location...</p>
            </div>
          </div>
        )}
        
        {error && (
          <div className="location-status location-error">
            <p>
              <span>📍</span> 
              {error === 'denied' 
                ? 'Location access was denied. Please enable location services to use your current location.' 
                : 'Could not detect your location. Please try again or select from the list below.'}
            </p>
          </div>
        )}
        
        <div className="locations-grid">
          {currentLocation && (
            <div 
              className="location-card current-location"
              onClick={() => handleLocationSelect(currentLocation.id)}
            >
              <div className="location-image-container">
                <img 
                  src={currentLocation.image} 
                  alt={currentLocation.name} 
                  className="location-image"
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = 'https://via.placeholder.com/300x200?text=Current+Location';
                  }}
                />
                <div className="location-badge">
                  <span>📍 Current</span>
                </div>
              </div>
              <div className="location-info">
                <h3 className="location-name">{currentLocation.name}</h3>
                <p className="location-country">{currentLocation.coordinates}</p>
              </div>
            </div>
          )}
          
          {filteredLocations.map(location => (
            <div 
              key={location.id}
              className="location-card"
              onClick={() => handleLocationSelect(location.id)}
            >
              <div className="location-image-container">
                <img 
                  src={location.image} 
                  alt={location.name} 
                  className="location-image"
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = `https://via.placeholder.com/300x200?text=${location.name}`;
                  }}
                />
              </div>
              <div className="location-info">
                <h3 className="location-name">{location.name}</h3>
                <p className="location-country">{location.country}</p>
              </div>
            </div>
          ))}
          
          {filteredLocations.length === 0 && (
            <div className="no-results">
              <p>No locations found matching "{searchQuery}"</p>
              <p>Try a different search term or select from popular locations.</p>
            </div>
          )}
        </div>
        
        <div className="location-custom">
          <p>Don't see your location?</p>
          <button 
            className="btn btn-secondary"
            onClick={() => navigate('/design/custom')}
          >
            Enter Custom Location
          </button>
        </div>
      </div>
    </div>
  );
};

export default LocationSelectPage;