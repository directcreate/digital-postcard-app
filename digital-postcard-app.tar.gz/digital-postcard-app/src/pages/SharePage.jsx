import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import './SharePage.css';

// In a real app, this would fetch the postcard data from an API
// For now, we'll just use mock data
const getPostcardData = (postcardId) => {
  // Extract location ID from the postcard ID
  const locationId = postcardId.split('-')[0];
  
  // Mock data based on location
  return {
    id: postcardId,
    location: {
      name: locationId.charAt(0).toUpperCase() + locationId.slice(1),
      country: locationId === 'paris' ? 'France' : 
               locationId === 'rome' ? 'Italy' : 
               locationId === 'newyork' ? 'USA' : 'Worldwide'
    },
    image: {
      url: `https://source.unsplash.com/random/800x600/?${locationId}`,
      title: `${locationId.charAt(0).toUpperCase() + locationId.slice(1)} View`,
      photographer: 'Unsplash Photographer'
    },
    message: 'Having a wonderful time in this beautiful place! The views are breathtaking and the food is amazing. Wish you were here to enjoy it with me!',
    recipient: 'Friend',
    sender: 'Your Name',
    created: new Date().toISOString(),
    deliveryMethod: 'digital', // or 'print'
    printOption: 'local',      // or 'international'
    shareLink: `https://digitalpostcard.app/p/${postcardId}`
  };
};

const SharePage = () => {
  const { postcardId } = useParams();
  const navigate = useNavigate();
  const [postcard, setPostcard] = useState(null);
  const [isSharing, setIsSharing] = useState(false);
  const [shareSuccess, setShareSuccess] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);
  const [printStatus, setPrintStatus] = useState(null);

  useEffect(() => {
    // In a real app, this would be an API call
    const data = getPostcardData(postcardId);
    setPostcard(data);

    // If the delivery method is print, show print status
    if (data.deliveryMethod === 'print') {
      setPrintStatus('processing');
    }
  }, [postcardId]);

  const handleShare = () => {
    // Check if the Web Share API is supported by the browser
    if (navigator.share) {
      setIsSharing(true);
      
      // In a real app, we'd generate a proper sharable URL and image
      navigator.share({
        title: `Postcard from ${postcard.location.name}`,
        text: `Check out this postcard I sent from ${postcard.location.name}!`,
        url: postcard.shareLink
      })
      .then(() => {
        setShareSuccess(true);
        setIsSharing(false);
      })
      .catch(error => {
        console.error('Error sharing:', error);
        setIsSharing(false);
      });
    } else {
      // Fallback for browsers that don't support the Web Share API
      console.log('Web Share API not supported');
      handleCopyLink();
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(postcard.shareLink)
      .then(() => {
        setCopySuccess(true);
        setTimeout(() => setCopySuccess(false), 2000);
      })
      .catch(err => {
        console.error('Could not copy link: ', err);
      });
  };

  const handleDownload = () => {
    // In a real app, this would generate and download the postcard image
    // For now, we'll just simulate the download
    alert('Download functionality would save the postcard image to your device.');
  };

  const handleCreateNew = () => {
    navigate('/select-location');
  };

  if (!postcard) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading sharing options...</p>
      </div>
    );
  }

  return (
    <div className="share-page">
      <div className="container">
        <div className="share-header">
          <h1 className="page-title">Share Your Postcard</h1>
          
          {postcard.deliveryMethod === 'digital' ? (
            <p className="share-subtitle">
              Your digital postcard is ready! Share it via social media, messaging apps, or email.
            </p>
          ) : (
            <p className="share-subtitle">
              Your physical postcard is being processed! You can also share a digital version.
            </p>
          )}
        </div>
        
        {printStatus && (
          <div className={`print-status ${printStatus}`}>
            <div className="status-icon">
              {printStatus === 'processing' && '🔄'}
              {printStatus === 'printing' && '🖨️'}
              {printStatus === 'mailed' && '📬'}
              {printStatus === 'delivered' && '✅'}
            </div>
            <div className="status-info">
              <h3 className="status-title">
                {printStatus === 'processing' && 'Processing Order'}
                {printStatus === 'printing' && 'Printing Postcard'}
                {printStatus === 'mailed' && 'Postcard Mailed'}
                {printStatus === 'delivered' && 'Postcard Delivered'}
              </h3>
              <p className="status-description">
                {printStatus === 'processing' && 'Your postcard order is being processed. We'll print it soon!'}
                {printStatus === 'printing' && 'Your postcard is being printed and prepared for shipping.'}
                {printStatus === 'mailed' && 'Your postcard has been mailed and is on its way!'}
                {printStatus === 'delivered' && 'Your postcard has been delivered. We hope they love it!'}
              </p>
              <div className="status-bar">
                <div className={`status-progress ${printStatus}`}></div>
              </div>
              <div className="estimated-delivery">
                Estimated delivery: {new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString()}
              </div>
            </div>
          </div>
        )}
        
        <div className="postcard-share-preview">
          <div className="postcard-thumbnail">
            <img 
              src={postcard.image.url} 
              alt={postcard.image.title}
              className="postcard-thumb-image"
              onError={(e) => {
                e.target.onerror = null;
                e.target.src = `https://via.placeholder.com/400x300?text=${postcard.location.name}`;
              }}
            />
          </div>
          
          <div className="postcard-share-info">
            <h2 className="postcard-location">
              {postcard.location.name}, {postcard.location.country}
            </h2>
            <p className="postcard-message-excerpt">
              {postcard.message.length > 100 
                ? postcard.message.substring(0, 100) + '...' 
                : postcard.message}
            </p>
            <p className="sender-info">
              From: {postcard.sender} • To: {postcard.recipient}
            </p>
          </div>
        </div>
        
        <div className="share-options">
          <div className="share-section">
            <h3 className="share-section-title">Share Options</h3>
            <div className="share-buttons">
              <button 
                className="share-btn"
                onClick={handleShare}
                disabled={isSharing}
              >
                <span className="share-icon">🔗</span>
                <span className="share-text">Share</span>
              </button>
              
              <button 
                className="share-btn"
                onClick={handleCopyLink}
              >
                <span className="share-icon">📋</span>
                <span className="share-text">
                  {copySuccess ? 'Copied!' : 'Copy Link'}
                </span>
              </button>
              
              <button 
                className="share-btn"
                onClick={handleDownload}
              >
                <span className="share-icon">💾</span>
                <span className="share-text">Download</span>
              </button>
              
              <a 
                href={`mailto:?subject=Postcard from ${postcard.location.name}&body=Check out this postcard I sent from ${postcard.location.name}! ${postcard.shareLink}`}
                className="share-btn"
              >
                <span className="share-icon">📧</span>
                <span className="share-text">Email</span>
              </a>
            </div>
          </div>
          
          <div className="direct-share-section">
            <h3 className="share-section-title">Direct Share</h3>
            <div className="direct-share-buttons">
              <a 
                href={`https://wa.me/?text=Check out this postcard I sent from ${postcard.location.name}! ${postcard.shareLink}`}
                target="_blank"
                rel="noopener noreferrer"
                className="direct-share-btn whatsapp"
              >
                WhatsApp
              </a>
              
              <a 
                href={`https://t.me/share/url?url=${encodeURIComponent(postcard.shareLink)}&text=Check out this postcard I sent from ${postcard.location.name}!`}
                target="_blank"
                rel="noopener noreferrer"
                className="direct-share-btn telegram"
              >
                Telegram
              </a>
              
              <a 
                href={`https://twitter.com/intent/tweet?text=Check out this postcard I sent from ${postcard.location.name}!&url=${encodeURIComponent(postcard.shareLink)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="direct-share-btn twitter"
              >
                Twitter
              </a>
              
              <a 
                href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(postcard.shareLink)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="direct-share-btn facebook"
              >
                Facebook
              </a>
            </div>
          </div>
        </div>
        
        <div className="share-instructions">
          <h3 className="instruction-title">How to Share</h3>
          <ol className="instruction-steps">
            <li>
              <span className="step-number">1</span>
              <span className="step-text">Click one of the share options above</span>
            </li>
            <li>
              <span className="step-number">2</span>
              <span className="step-text">Select recipients or paste the link in your preferred app</span>
            </li>
            <li>
              <span className="step-number">3</span>
              <span className="step-text">Add a personal message if desired</span>
            </li>
            <li>
              <span className="step-number">4</span>
              <span className="step-text">Send your postcard!</span>
            </li>
          </ol>
        </div>
        
        <div className="next-actions">
          <Link to={`/preview/${postcardId}`} className="btn btn-secondary">
            Back to Preview
          </Link>
          
          <button 
            className="btn btn-primary"
            onClick={handleCreateNew}
          >
            Create Another Postcard
          </button>
        </div>
      </div>
    </div>
  );
};

export default SharePage;