import React from 'react';
import { Link } from 'react-router-dom';
import './NotFoundPage.css';

const NotFoundPage = () => {
  return (
    <div className="not-found-page">
      <div className="container">
        <div className="not-found-content">
          <div className="not-found-icon">
            <div className="lost-postcard">
              <div className="postcard-front">
                <span className="question-mark">?</span>
              </div>
              <div className="postcard-shadow"></div>
            </div>
          </div>
          
          <h1 className="not-found-title">Page Not Found</h1>
          <p className="not-found-message">
            Oops! It looks like this postcard got lost in transit.
          </p>
          <p className="not-found-submessage">
            The page you're looking for doesn't exist or has been moved.
          </p>
          
          <div className="not-found-actions">
            <Link to="/" className="btn btn-primary">
              Return Home
            </Link>
            <Link to="/select-location" className="btn btn-secondary">
              Create a Postcard
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;