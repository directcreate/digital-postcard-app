import React, { lazy, Suspense } from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import LoadingScreen from './components/common/LoadingScreen';

// Lazy-loaded pages for better performance
const HomePage = lazy(() => import('./pages/HomePage'));
const LocationSelectPage = lazy(() => import('./pages/LocationSelectPage'));
const PostcardDesignPage = lazy(() => import('./pages/PostcardDesignPage'));
const PostcardPreviewPage = lazy(() => import('./pages/PostcardPreviewPage'));
const SharePage = lazy(() => import('./pages/SharePage'));
const NotFoundPage = lazy(() => import('./pages/NotFoundPage'));

function App() {
  return (
    <>
      <Header />
      <main className="app-content">
        <Suspense fallback={<LoadingScreen />}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/select-location" element={<LocationSelectPage />} />
            <Route path="/design/:locationId" element={<PostcardDesignPage />} />
            <Route path="/preview/:postcardId" element={<PostcardPreviewPage />} />
            <Route path="/share/:postcardId" element={<SharePage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </Suspense>
      </main>
      <Footer />
    </>
  );
}

export default App;