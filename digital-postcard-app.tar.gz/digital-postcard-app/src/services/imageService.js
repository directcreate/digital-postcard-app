/**
 * Service for handling postcard images
 */

// In a real app, these would come from an API like Unsplash or Pexels
const LOCATION_IMAGES = {
  'paris': [
    {
      id: 'paris-1',
      url: 'https://source.unsplash.com/random/800x600/?paris,eiffel',
      title: 'Eiffel Tower',
      photographer: 'Photographer 1',
      isPremium: false
    },
    {
      id: 'paris-2',
      url: 'https://source.unsplash.com/random/800x600/?paris,louvre',
      title: 'Louvre Museum',
      photographer: 'Photographer 2',
      isPremium: false
    },
    {
      id: 'paris-3',
      url: 'https://source.unsplash.com/random/800x600/?paris,montmartre',
      title: 'Montmartre',
      photographer: 'Photographer 3',
      isPremium: true
    },
    {
      id: 'paris-4',
      url: 'https://source.unsplash.com/random/800x600/?paris,notredame',
      title: 'Notre Dame Cathedral',
      photographer: 'Photographer 4',
      isPremium: true
    }
  ],
  'rome': [
    {
      id: 'rome-1',
      url: 'https://source.unsplash.com/random/800x600/?rome,colosseum',
      title: 'Colosseum',
      photographer: 'Photographer 5',
      isPremium: false
    },
    {
      id: 'rome-2',
      url: 'https://source.unsplash.com/random/800x600/?rome,vatican',
      title: 'Vatican City',
      photographer: 'Photographer 6',
      isPremium: false
    },
    {
      id: 'rome-3',
      url: 'https://source.unsplash.com/random/800x600/?rome,trevi',
      title: 'Trevi Fountain',
      photographer: 'Photographer 7',
      isPremium: true
    }
  ],
  'newyork': [
    {
      id: 'newyork-1',
      url: 'https://source.unsplash.com/random/800x600/?newyork,timessquare',
      title: 'Times Square',
      photographer: 'Photographer 8',
      isPremium: false
    },
    {
      id: 'newyork-2',
      url: 'https://source.unsplash.com/random/800x600/?newyork,centralpark',
      title: 'Central Park',
      photographer: 'Photographer 9',
      isPremium: false
    },
    {
      id: 'newyork-3',
      url: 'https://source.unsplash.com/random/800x600/?newyork,brooklyn',
      title: 'Brooklyn Bridge',
      photographer: 'Photographer 10',
      isPremium: true
    }
  ],
  'tokyo': [
    {
      id: 'tokyo-1',
      url: 'https://source.unsplash.com/random/800x600/?tokyo,shibuya',
      title: 'Shibuya Crossing',
      photographer: 'Photographer 11',
      isPremium: false
    },
    {
      id: 'tokyo-2',
      url: 'https://source.unsplash.com/random/800x600/?tokyo,temple',
      title: 'Senso-ji Temple',
      photographer: 'Photographer 12',
      isPremium: false
    }
  ],
  'current': [
    {
      id: 'current-1',
      url: 'https://source.unsplash.com/random/800x600/?city',
      title: 'City View',
      photographer: 'Photographer 13',
      isPremium: false
    },
    {
      id: 'current-2',
      url: 'https://source.unsplash.com/random/800x600/?landmark',
      title: 'Local Landmark',
      photographer: 'Photographer 14',
      isPremium: false
    }
  ],
  'custom': [
    {
      id: 'custom-1',
      url: 'https://source.unsplash.com/random/800x600/?travel',
      title: 'Custom View 1',
      photographer: 'Photographer 15',
      isPremium: false
    },
    {
      id: 'custom-2',
      url: 'https://source.unsplash.com/random/800x600/?landscape',
      title: 'Custom View 2',
      photographer: 'Photographer 16',
      isPremium: false
    }
  ]
};

// Default images for any location not explicitly defined
const DEFAULT_IMAGES = [
  {
    id: 'default-1',
    url: 'https://source.unsplash.com/random/800x600/?travel',
    title: 'Scenic View',
    photographer: 'Unsplash Photographer',
    isPremium: false
  },
  {
    id: 'default-2',
    url: 'https://source.unsplash.com/random/800x600/?landmark',
    title: 'Famous Landmark',
    photographer: 'Unsplash Photographer',
    isPremium: false
  }
];

/**
 * Get images for a specific location
 * @param {string} locationId - The location ID
 * @returns {Array} Array of image objects for the location
 */
export const getImagesForLocation = (locationId) => {
  // If we have specific images for this location, return them
  if (LOCATION_IMAGES[locationId]) {
    return LOCATION_IMAGES[locationId];
  }
  
  // Otherwise, return default images with the location ID embedded
  return DEFAULT_IMAGES.map(image => ({
    ...image,
    id: `${locationId}-${image.id}`,
    url: `https://source.unsplash.com/random/800x600/?${locationId}`
  }));
};

/**
 * Get a specific image by ID
 * @param {string} imageId - The image ID
 * @returns {Object|null} The image object or null if not found
 */
export const getImageById = (imageId) => {
  // Extract location ID from image ID (format: location-imageNumber)
  const parts = imageId.split('-');
  const locationId = parts[0];
  
  // Get all images for that location
  const locationImages = getImagesForLocation(locationId);
  
  // Find the specific image
  return locationImages.find(image => image.id === imageId) || null;
};

/**
 * Check if an image is premium
 * @param {string} imageId - The image ID
 * @returns {boolean} True if the image is premium
 */
export const isImagePremium = (imageId) => {
  const image = getImageById(imageId);
  return image ? image.isPremium : false;
};

/**
 * In a real app, this would call an API like Unsplash or Pexels
 * @param {string} locationName - The location name to search for
 * @returns {Promise} Promise resolving to an array of image objects
 */
export const searchLocationImages = async (locationName) => {
  // This is a mock implementation
  return new Promise((resolve) => {
    setTimeout(() => {
      // Convert the location name to a format usable as a location ID
      const locationId = locationName.toLowerCase().replace(/\s+/g, '');
      resolve(getImagesForLocation(locationId));
    }, 500); // Simulate API delay
  });
};