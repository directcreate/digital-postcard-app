/**
 * Service for handling postcard operations
 */

// In a real app, these would be stored in a database
let POSTCARDS = {};

/**
 * Create a new postcard
 * @param {Object} postcardData - The postcard data
 * @returns {Promise} Promise resolving to the created postcard object
 */
export const createPostcard = async (postcardData) => {
  // Generate a unique ID
  const postcardId = `${postcardData.locationId}-${Date.now()}`;
  
  // Create the postcard object
  const postcard = {
    id: postcardId,
    ...postcardData,
    created: new Date().toISOString(),
    status: 'created'
  };
  
  // In a real app, this would be saved to a database
  POSTCARDS[postcardId] = postcard;
  
  // Simulate API delay
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(postcard);
    }, 300);
  });
};

/**
 * Get a postcard by ID
 * @param {string} postcardId - The postcard ID
 * @returns {Promise} Promise resolving to the postcard object or null if not found
 */
export const getPostcardById = async (postcardId) => {
  // In a real app, this would fetch from a database
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(POSTCARDS[postcardId] || null);
    }, 300);
  });
};

/**
 * Update a postcard
 * @param {string} postcardId - The postcard ID
 * @param {Object} updates - The updates to apply
 * @returns {Promise} Promise resolving to the updated postcard object
 */
export const updatePostcard = async (postcardId, updates) => {
  // In a real app, this would update a database record
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (!POSTCARDS[postcardId]) {
        reject(new Error(`Postcard with ID ${postcardId} not found`));
        return;
      }
      
      POSTCARDS[postcardId] = {
        ...POSTCARDS[postcardId],
        ...updates,
        updated: new Date().toISOString()
      };
      
      resolve(POSTCARDS[postcardId]);
    }, 300);
  });
};

/**
 * Delete a postcard
 * @param {string} postcardId - The postcard ID
 * @returns {Promise} Promise resolving to a success message
 */
export const deletePostcard = async (postcardId) => {
  // In a real app, this would delete from a database
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (!POSTCARDS[postcardId]) {
        reject(new Error(`Postcard with ID ${postcardId} not found`));
        return;
      }
      
      delete POSTCARDS[postcardId];
      resolve({ message: 'Postcard deleted successfully' });
    }, 300);
  });
};

/**
 * Get all postcards for a user
 * In a real app, this would be filtered by user ID
 * @returns {Promise} Promise resolving to an array of postcard objects
 */
export const getUserPostcards = async () => {
  // In a real app, this would fetch from a database filtered by user ID
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(Object.values(POSTCARDS));
    }, 300);
  });
};

/**
 * Generate a sharing link for a postcard
 * @param {string} postcardId - The postcard ID
 * @returns {string} The sharing link
 */
export const generateSharingLink = (postcardId) => {
  // In a real app, this might generate a signed URL or a short link
  return `https://digitalpostcard.app/p/${postcardId}`;
};

/**
 * Process a physical postcard order
 * @param {string} postcardId - The postcard ID
 * @param {Object} deliveryDetails - The delivery details
 * @returns {Promise} Promise resolving to the order status
 */
export const processPhysicalPostcard = async (postcardId, deliveryDetails) => {
  // In a real app, this would call a print fulfillment API like Gelato
  return new Promise((resolve) => {
    setTimeout(() => {
      // Update the postcard with delivery info
      if (POSTCARDS[postcardId]) {
        POSTCARDS[postcardId] = {
          ...POSTCARDS[postcardId],
          deliveryMethod: 'print',
          deliveryDetails,
          printStatus: 'processing',
          printOrderDate: new Date().toISOString()
        };
      }
      
      resolve({
        success: true,
        postcardId,
        orderId: `ORD-${Date.now()}`,
        status: 'processing',
        estimatedDelivery: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
      });
    }, 500);
  });
};