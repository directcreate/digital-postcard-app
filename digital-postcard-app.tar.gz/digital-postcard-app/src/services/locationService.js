/**
 * Service for handling location data and related image lookups
 */

// This is a mock implementation - in a real app, this would call an API
const POPULAR_LOCATIONS = [
  { id: 'paris', name: 'Paris', country: 'France', coordinates: { lat: 48.8566, lng: 2.3522 } },
  { id: 'rome', name: 'Rome', country: 'Italy', coordinates: { lat: 41.9028, lng: 12.4964 } },
  { id: 'newyork', name: 'New York', country: 'USA', coordinates: { lat: 40.7128, lng: -74.0060 } },
  { id: 'tokyo', name: 'Tokyo', country: 'Japan', coordinates: { lat: 35.6762, lng: 139.6503 } },
  { id: 'sydney', name: 'Sydney', country: 'Australia', coordinates: { lat: -33.8688, lng: 151.2093 } },
  { id: 'london', name: 'London', country: 'UK', coordinates: { lat: 51.5074, lng: -0.1278 } },
  { id: 'barcelona', name: 'Barcelona', country: 'Spain', coordinates: { lat: 41.3851, lng: 2.1734 } },
  { id: 'dubai', name: 'Dubai', country: 'UAE', coordinates: { lat: 25.2048, lng: 55.2708 } },
];

/**
 * Get all popular locations
 * @returns {Array} Array of location objects
 */
export const getPopularLocations = () => {
  return POPULAR_LOCATIONS;
};

/**
 * Find a location by ID
 * @param {string} locationId - The location ID to find
 * @returns {Object|null} The location object or null if not found
 */
export const getLocationById = (locationId) => {
  return POPULAR_LOCATIONS.find((location) => location.id === locationId) || null;
};

/**
 * Search locations by name or country
 * @param {string} query - The search query
 * @returns {Array} Filtered array of location objects
 */
export const searchLocations = (query) => {
  if (!query || query.trim() === '') {
    return POPULAR_LOCATIONS;
  }
  
  const normalizedQuery = query.toLowerCase().trim();
  
  return POPULAR_LOCATIONS.filter(
    (location) => 
      location.name.toLowerCase().includes(normalizedQuery) || 
      location.country.toLowerCase().includes(normalizedQuery)
  );
};

/**
 * Find the nearest location to the given coordinates
 * @param {Object} coordinates - The coordinates object with lat and lng properties
 * @returns {Object|null} The nearest location or null if no locations available
 */
export const findNearestLocation = (coordinates) => {
  if (!coordinates || !coordinates.latitude || !coordinates.longitude) {
    return null;
  }
  
  // Calculate distance using Haversine formula
  const getDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371; // Radius of the Earth in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distance in km
  };
  
  if (POPULAR_LOCATIONS.length === 0) {
    return null;
  }
  
  let nearestLocation = POPULAR_LOCATIONS[0];
  let minDistance = getDistance(
    coordinates.latitude, 
    coordinates.longitude,
    nearestLocation.coordinates.lat,
    nearestLocation.coordinates.lng
  );
  
  for (let i = 1; i < POPULAR_LOCATIONS.length; i++) {
    const location = POPULAR_LOCATIONS[i];
    const distance = getDistance(
      coordinates.latitude,
      coordinates.longitude,
      location.coordinates.lat,
      location.coordinates.lng
    );
    
    if (distance < minDistance) {
      minDistance = distance;
      nearestLocation = location;
    }
  }
  
  return nearestLocation;
};

/**
 * Reverse geocode coordinates to get location name
 * In a real app, this would call a service like Google Maps Geocoding API
 * @param {Object} coordinates - The coordinates object with lat and lng properties
 * @returns {Promise} Promise resolving to a location object
 */
export const reverseGeocode = async (coordinates) => {
  // This is a mock implementation
  // In a real app, this would call a geocoding API
  
  return new Promise((resolve) => {
    setTimeout(() => {
      const nearestLocation = findNearestLocation(coordinates);
      
      if (nearestLocation) {
        resolve({
          id: 'current',
          name: nearestLocation.name,
          country: nearestLocation.country,
          coordinates: {
            lat: coordinates.latitude,
            lng: coordinates.longitude
          }
        });
      } else {
        // If no known location is close, create a generic "Current Location"
        resolve({
          id: 'current',
          name: 'Your Location',
          country: 'Current Position',
          coordinates: {
            lat: coordinates.latitude,
            lng: coordinates.longitude
          }
        });
      }
    }, 500); // Simulate API delay
  });
};