import React from 'react';
import './LoadingScreen.css';

const LoadingScreen = () => {
  return (
    <div className="loading-screen">
      <div className="loading-content">
        <div className="postcard-loader">
          <div className="postcard">
            <div className="postcard-front"></div>
            <div className="postcard-back"></div>
          </div>
        </div>
        <p className="loading-text">Loading your postcards...</p>
      </div>
    </div>
  );
};

export default LoadingScreen;