import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="app-footer">
      <div className="container">
        <div className="footer-grid">
          <div className="footer-section">
            <h3 className="footer-title">Digital Postcard App</h3>
            <p className="footer-description">
              Share your travel experiences with personalized digital postcards.
              Choose from beautiful, location-based images and add your personal touch.
            </p>
          </div>
          
          <div className="footer-section">
            <h3 className="footer-title">Quick Links</h3>
            <ul className="footer-links">
              <li><Link to="/">Home</Link></li>
              <li><Link to="/select-location">Create Postcard</Link></li>
              <li><Link to="/about">About Us</Link></li>
              <li><Link to="/privacy">Privacy Policy</Link></li>
              <li><Link to="/terms">Terms of Service</Link></li>
            </ul>
          </div>
          
          <div className="footer-section">
            <h3 className="footer-title">Contact</h3>
            <ul className="footer-contact">
              <li>
                <span className="contact-icon">✉️</span>
                <a href="mailto:info@digitalpostcard.app">info@digitalpostcard.app</a>
              </li>
              <li>
                <span className="contact-icon">📱</span>
                <span>Follow us on social media</span>
              </li>
              <li className="social-links">
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" aria-label="Twitter">
                  <span className="social-icon">𝕏</span>
                </a>
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
                  <span className="social-icon">📷</span>
                </a>
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                  <span className="social-icon">ⓕ</span>
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="footer-bottom">
          <p>&copy; {currentYear} Digital Postcard App. All rights reserved.</p>
          <p className="attribution">
            Images provided by 
            <a href="https://unsplash.com" target="_blank" rel="noopener noreferrer"> Unsplash</a> and
            <a href="https://pexels.com" target="_blank" rel="noopener noreferrer"> Pexels</a>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;