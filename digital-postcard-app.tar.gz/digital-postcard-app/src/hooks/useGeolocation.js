import { useState, useEffect } from 'react';

/**
 * Custom hook for accessing and monitoring device geolocation
 * @param {Object} options - Geolocation API options
 * @param {boolean} options.enableHighAccuracy - Whether to enable high accuracy mode
 * @param {number} options.timeout - Timeout for position request in milliseconds
 * @param {number} options.maximumAge - Maximum age of cached position in milliseconds
 * @returns {Object} Geolocation state with location, loading, and error information
 */
const useGeolocation = (options = {}) => {
  const [location, setLocation] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser');
      setLoading(false);
      return;
    }

    const defaultOptions = {
      enableHighAccuracy: false,
      timeout: 10000,
      maximumAge: 0,
    };

    const geoOptions = { ...defaultOptions, ...options };

    const handleSuccess = (position) => {
      setLocation({
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracy: position.coords.accuracy,
        timestamp: position.timestamp,
      });
      setLoading(false);
      setError(null);
    };

    const handleError = (error) => {
      setError(error.code === 1 ? 'denied' : error.message);
      setLoading(false);
    };

    const watchId = navigator.geolocation.watchPosition(
      handleSuccess,
      handleError,
      geoOptions
    );

    // Clean up by clearing the watch
    return () => navigator.geolocation.clearWatch(watchId);
  }, [options]);

  return { location, loading, error };
};

export default useGeolocation;